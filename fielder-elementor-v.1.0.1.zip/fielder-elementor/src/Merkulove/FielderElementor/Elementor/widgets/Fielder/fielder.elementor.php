<?php /** @noinspection PhpUndefinedClassInspection */
/**
 * Fielder for Elementor
 * Customizable custom fields for Elementor editor
 * Exclusively on https://1.envato.market/fielder-elementor
 *
 * @encoding        UTF-8
 * @version         1.0.1
 * @copyright       (C) 2018 - 2022 Merkulove ( https://merkulov.design/ ). All rights reserved.
 * @license         Envato License https://1.envato.market/KYbje
 * @contributors    Nemirovskiy Vitaliy (nemirovskiyvitaliy@gmail.com), Dmitry Merkulov (dmitry@merkulov.design), Cherviakov Vlad (vladchervjakov@gmail.com)
 * @support         help@merkulov.design
 **/

namespace Merkulove\FielderElementor;

/** Exit if accessed directly. */
if ( ! defined( 'ABSPATH' ) ) {
    header( 'Status: 403 Forbidden' );
    header( 'HTTP/1.1 403 Forbidden' );
    exit;
}

use Elementor\Core\Schemes\Color;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Repeater;
use Exception;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Merkulove\FielderElementor\Unity\Plugin;
use Merkulove\FielderElementor\Unity\Plugin as UnityPlugin;

/** @noinspection PhpUnused */
/**
 * Fielder - Custom Elementor Widget.
 **/
class fielder_elementor extends Widget_Base {

    /**
     * Use this to sort widgets.
     * A smaller value means earlier initialization of the widget.
     * Can take negative values.
     * Default widgets and widgets from 3rd party developers have 0 $mdp_order
     **/
    public $mdp_order = 1;

    /**
     * Widget base constructor.
     * Initializing the widget base class.
     *
     * @access public
     * @throws Exception If arguments are missing when initializing a full widget instance.
     * @param array      $data Widget data. Default is an empty array.
     * @param array|null $args Optional. Widget default arguments. Default is null.
     *
     * @return void
     **/
    public function __construct( $data = [], $args = null ) {

        parent::__construct( $data, $args );

        wp_register_style(
       'mdp-fielder-elementor-admin',
          UnityPlugin::get_url() . 'src/Merkulove/Unity/assets/css/elementor-admin' . UnityPlugin::get_suffix() . '.css',
              [],
              UnityPlugin::get_version()
        );

        wp_register_style(
       'mdp-fielder-elementor',
          UnityPlugin::get_url() . 'css/fielder-elementor' . UnityPlugin::get_suffix() . '.css',
              [],
              UnityPlugin::get_version()
        );

    }

    /**
     * Return a widget name.
     *
     * @return string
     **/
    public function get_name() {

        return 'mdp-fielder-elementor';

    }

    /**
     * Return the widget title that will be displayed as the widget label.
     *
     * @return string
     **/
    public function get_title() {

        return esc_html__( 'Fielder', 'fielder-elementor' );

    }

    /**
     * Set the widget icon.
     *
     * @return string
     */
    public function get_icon() {

        return 'mdp-fielder-elementor-widget-icon';

    }

    /**
     * Set the category of the widget.
     *
     * @return array with category names
     **/
    public function get_categories() {

        return [ 'general' ];

    }

    /**
     * Get widget keywords. Retrieve the list of keywords the widget belongs to.
     *
     * @access public
     *
     * @return array Widget keywords.
     **/
    public function get_keywords() {

        return [ 'Merkulove', 'Fielder' ];

    }

    /**
     * Get style dependencies.
     * Retrieve the list of style dependencies the widget requires.
     *
     * @access public
     *
     * @return array Widget styles dependencies.
     **/
    public function get_style_depends() {

        return [ 'mdp-fielder-elementor', 'mdp-fielder-elementor-admin' ];

    }

	/**
	 * Get script dependencies.
	 * Retrieve the list of script dependencies the element requires.
	 *
	 * @access public
     *
	 * @return array Element scripts dependencies.
	 **/
	public function get_script_depends() {

		return [ 'mdp-fielder' ];

    }

    /**
     * Add the widget controls.
     *
     * @access protected
     * @return void with category names
     **/
    protected function register_controls() {

        /** Content Tab. */
        $this->tab_content();

        /** Style Tab. */
        $this->tab_style();

    }

    /**
     * Add widget controls on Content tab.
     *
     * @since 1.0.0
     * @access private
     *
     * @return void
     **/
    private function tab_content() {

        /** Content -> General Content Section. */
        $this->section_content_general();

    }

    /**
     * Add widget controls on Style tab.
     *
     * @since 1.0.0
     * @access private
     *
     * @return void
     **/
    private function tab_style() {

        /** Style -> Section Style Fields. */
        $this->section_style_fields();

        /** Style -> Section Style Prefix. */
        $this->section_style_prefix();

        /** Style -> Section Style Suffix. */
        $this->section_style_suffix();

    }


    /**
     * Get all custom fields.
     *
     * @param $fields
     * @return array
     * @since 1.0.0
     * @access private
     *
     */
    private function get_all_fields( $fields ) {
        $result = [];

        if ( !is_array( $fields ) ) { return; }

        foreach ( $fields as $key => $value ) {
            if ( !class_exists( 'ACF' ) && strpos( $key, '_' ) === 0 ) { continue; }
            $result[$key] = $key;
        }

        return $result;
    }

    /**
     * Add widget controls: Content -> General Content Section.
     *
     * @since 1.0.0
     * @access private
     *
     * @return void
     **/
    private function section_content_general() {

        $this->start_controls_section( 'section_content_general', [
            'label' => esc_html__( 'General', 'fielder-elementor' ),
            'tab'   => Controls_Manager::TAB_CONTENT
        ] );

        $repeater = new Repeater();

        $custom_fields = class_exists( 'ACF' ) ? get_fields() : get_post_meta( get_the_ID() );


        $select_fields = $this->get_all_fields( $custom_fields );

        $repeater->add_control(
            'custom_field',
            [
                'label' => esc_html__( 'Show Elements', 'fielder-elementor' ),
                'type' => Controls_Manager::SELECT2,
                'multiple' => false,
                'options' => $select_fields,
            ]
        );

        $repeater->add_control(
            'custom_field_type',
            [
                'label' => esc_html__( 'Field type', 'fielder-elementor' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'text',
                'options' => [
                    'text'  => esc_html__( 'Text', 'fielder-elementor' ),
                    'object'  => esc_html__( 'Object', 'fielder-elementor' ),
                    'array'  => esc_html__( 'Array', 'fielder-elementor' ),
                ],
            ]
        );

        $repeater->add_control(
            'array_key',
            [
                'label' => esc_html__( 'Array key', 'fielder-elementor' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => esc_html__( 'Type array key', 'fielder-elementor' ),
                'condition' => [
                    'custom_field_type' => 'array'
                ]
            ]
        );

        $repeater->add_control(
            'object_key',
            [
                'label' => esc_html__( 'Object key', 'fielder-elementor' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => esc_html__( 'Type object key', 'fielder-elementor' ),
                'condition' => [
                    'custom_field_type' => 'object'
                ]
            ]
        );

        $repeater->add_control(
            'show_icon',
            [
                'label' => esc_html__( 'Show icon', 'fielder-elementor' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'fielder-elementor' ),
                'label_off' => esc_html__( 'Hide', 'fielder-elementor' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $repeater->add_control(
            'field_icon',
            [
                'label' => esc_html__( 'Icon', 'fielder-elementor' ),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-star',
                    'library' => 'solid',
                ],
                'condition' => [
                        'show_icon' => 'yes'
                ]
            ]
        );

        $repeater->add_control(
            'icon_position',
            [
                'label' => esc_html__( 'Icon position', 'fielder-elementor' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'before',
                'options' => [
                    'before'  => esc_html__( 'Before', 'fielder-elementor' ),
                    'after'  => esc_html__( 'After', 'fielder-elementor' ),
                    'top-left'  => esc_html__( 'Top left', 'fielder-elementor' ),
                    'top-center'  => esc_html__( 'Top center', 'fielder-elementor' ),
                    'top-right'  => esc_html__( 'Top right', 'fielder-elementor' ),
                    'bottom-left'  => esc_html__( 'Bottom left', 'fielder-elementor' ),
                    'bottom-center'  => esc_html__( 'Bottom center', 'fielder-elementor' ),
                    'bottom-right'  => esc_html__( 'Bottom right', 'fielder-elementor' ),
                ],
                'condition' => [
                        'show_icon' => 'yes'
                ]
            ]
        );

        $repeater->add_control(
            'custom_field_text_align',
            [
                'label' => esc_html__( 'Text align', 'fielder-elementor' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'fielder-elementor' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'fielder-elementor' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'fielder-elementor' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'default' => 'center',
                'toggle' => true,
            ]
        );

        $repeater->add_control(
            'field_as_slug_link',
            [
                'label' => esc_html__( 'Use field as slug link', 'fielder-elementor' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'fielder-elementor' ),
                'label_off' => esc_html__( 'No', 'fielder-elementor' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $repeater->add_control(
            'custom_link',
            [
                'label' => esc_html__( 'Enable custom link', 'fielder-elementor' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'fielder-elementor' ),
                'label_off' => esc_html__( 'No', 'fielder-elementor' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                        'field_as_slug_link!' => 'yes'
                ]
            ]
        );

        $repeater->add_control(
            'custom_link_url',
            [
                'label' => esc_html__( 'Custom link', 'fielder-elementor' ),
                'type' => Controls_Manager::URL,
                'placeholder' => esc_html__( 'https://your-link.com', 'fielder-elementor' ),
                'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                        'custom_link' => 'yes',
                        'field_as_slug_link!' => 'yes'
                ]
            ]
        );

        $repeater->add_control(
            'field_prefix',
            [
                'label' => esc_html__( 'Prefix', 'fielder-elementor' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => esc_html__( 'Type your prefix here', 'fielder-elementor' ),
            ]
        );

        $repeater->add_control(
            'field_suffix',
            [
                'label' => esc_html__( 'Suffix', 'fielder-elementor' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => esc_html__( 'Type your suffix here', 'fielder-elementor' ),
            ]
        );

        $this->add_control(
            'custom_fields',
            [
                'label' => esc_html__( 'Custom fields', 'fielder-elementor' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'custom_field' => esc_html__( 'Title #1', 'fielder-elementor' ),
                    ],
                ],
                'title_field' => '{{{ custom_field }}}',
            ]
        );

        $this->end_controls_section();

    }

    /**
     * Method for generating margin padding controls.
     *
     * @param $section_id
     * @param $html_class
     * @param array $default_padding
     * @param array $default_margin
     * @return void
     * @since 1.0.0
     * @access private
     */
    private function generate_margin_padding_controls( $section_id, $html_class, $default_padding = [], $default_margin = [] ) {


        $this->add_responsive_control(
            $section_id.'_margin',
            [
                'label' => esc_html__( 'Margin', 'fielder-elementor' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'default' => $default_margin,
                'selectors' => [
                    "{{WRAPPER}} .$html_class" => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            $section_id.'_padding',
            [
                'label' => esc_html__( 'Padding', 'fielder-elementor' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'default' => $default_padding,
                'selectors' => [
                    "{{WRAPPER}} .$html_class" => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    }

    /**
     * Function for generating typography and tabs controls.
     *
     * @param $section_id
     * @param $opts
     * @return void
     * @since 1.0.0
     * @access private
     */
    private function generate_typography_tabs_controls( $section_id, $opts = [] ) {
        $style_opts = [
            'html_class' => array_key_exists( 'html_class', $opts ) ?
                $opts['html_class'] : '',
            'active_class' => array_key_exists( 'active_class', $opts ) ?
                $opts['active_class'] : '',
            'include_color' => array_key_exists( 'include_color', $opts ) ?
                $opts['include_color'] : true,
            'include_bg' => array_key_exists( 'include_bg', $opts ) ?
                $opts['include_color'] : true,
            'include_typography' => array_key_exists( 'include_typography', $opts ) ?
                $opts['include_typography'] : true,
            'include_transition' => array_key_exists( 'include_transition', $opts ) ?
                $opts['include_transition'] : true,
            'additional_color' => array_key_exists( 'additional_color', $opts ) ?
                $opts['additional_color'] : false,
            'include_active_tab' => array_key_exists( 'include_active_tab', $opts ) ?
                $opts['include_active_tab'] : false,
            'active_tab_name' => array_key_exists( 'active_tab_name', $opts ) ?
                $opts['active_tab_name'] : 'ACTIVE',
            'color_prefix' => array_key_exists( 'color_prefix', $opts ) ?
                $opts['color_prefix'] : '',
            'color_class' => array_key_exists( 'color_class', $opts ) ?
                $opts['color_class'] : '',
            'color_hover_class' => array_key_exists( 'color_hover_class', $opts ) ?
                $opts['color_hover_class'] : '',
            'color_active_class' => array_key_exists( 'color_active_class', $opts ) ?
                $opts['color_active_class'] : '',
            'color_hover_selector' => array_key_exists( 'color_hover_selector', $opts ) ?
                $opts['color_hover_selector'] : '',
            'additional_color_name' => array_key_exists( 'additional_color_name', $opts ) ?
                $opts['additional_color_name'] : '',
            'additional_color_class' => array_key_exists( 'additional_color_class', $opts ) ?
                $opts['additional_color_class'] : '',
            'additional_color_hover_class' => array_key_exists( 'additional_color_hover_class', $opts ) ?
                $opts['additional_color_hover_class'] : '',
            'additional_color_active_class' => array_key_exists( 'additional_color_active_class', $opts ) ?
                $opts['additional_color_active_class'] : '',
            'additional_transition_selector' => array_key_exists( 'additional_transition_selector', $opts ) ?
                $opts['additional_transition_selector'] : '',
            'typography_class' => array_key_exists( 'typography_class', $opts ) ?
                $opts['typography_class'] : '',
            'color_scheme_default' => array_key_exists( 'color_scheme_default', $opts ) ?
                $opts['color_scheme_default'] : Color::COLOR_3,
            'additional_color_scheme_default' => array_key_exists( 'additional_color_scheme_default', $opts ) ?
                $opts['additional_color_scheme_default'] : Color::COLOR_3
        ];


        if ( $style_opts['include_typography'] ) {
            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => $section_id . '_typography',
                    'label' => esc_html__('Typography', 'fielder-elementor'),
                    'scheme' => Typography::TYPOGRAPHY_1,
                    'selector' => "{{WRAPPER}} .".$style_opts['typography_class'],
                ]
            );
        }

        $this->start_controls_tabs( $section_id.'_style_tabs' );

        $this->start_controls_tab(
            $section_id.'_normal_style_tab',
            ['label' => esc_html__( 'NORMAL', 'fielder-elementor' )]
        );

        if ( $style_opts['include_color'] ) {
            $this->add_control(
                $section_id . '_normal_text_color',
                [
                    'label' => esc_html__($style_opts['color_prefix'].'Color', 'fielder-elementor'),
                    'type' => Controls_Manager::COLOR,
                    'scheme' => [
                        'type' => Color::get_type(),
                        'value' => $style_opts['color_scheme_default'],
                    ],
                    'selectors' => [
                        "{{WRAPPER}} .".$style_opts['color_class'] => 'color: {{VALUE}} !important;',
                    ],
                ]
            );

        }

        if ( $style_opts['additional_color'] ) {
            $this->add_control(
                $section_id . '_' . $style_opts['additional_color_name'] . '_normal_text_color',
                [
                    'label' => esc_html__( $style_opts['additional_color_name'], 'fielder-elementor' ),
                    'type' => Controls_Manager::COLOR,
                    'scheme' => [
                        'type' => Color::get_type(),
                        'value' => $style_opts['additional_color_scheme_default'],
                    ],
                    'selectors' => [
                        "{{WRAPPER}} .".$style_opts['additional_color_class'] => 'color: {{VALUE}} !important; fill: {{VALUE}};',

                    ],
                ]
            );
        }

        if ( $style_opts['include_bg'] ) {

            $this->add_group_control(
                Group_Control_Background::get_type(),
                [
                    'name' => $section_id . '_normal_background',
                    'label' => esc_html__('Background type', 'fielder-elementor'),
                    'types' => ['classic', 'gradient', 'video'],
                    'selector' => "{{WRAPPER}} .".$style_opts['html_class'],
                ]
            );

        }

        $this->add_control(
            $section_id . '_separate_normal',
            [
                'type' => Controls_Manager::DIVIDER,
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => $section_id.'_border_normal',
                'label' => esc_html__( 'Border Type', 'fielder-elementor' ),
                'selector' => "{{WRAPPER}} .".$style_opts['html_class'],
            ]
        );

        $this->add_responsive_control(
            $section_id.'_border_radius_normal',
            [
                'label' => esc_html__( 'Border radius', 'fielder-elementor' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    "{{WRAPPER}} .".$style_opts['html_class'] => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => $section_id.'_box_shadow_normal',
                'label' => esc_html__( 'Box Shadow', 'fielder-elementor' ),
                'selector' => "{{WRAPPER}} .".$style_opts['html_class'],
            ]
        );


        $this->end_controls_tab();

        $this->start_controls_tab(
            $section_id.'_hover_style_tab',
            ['label' => esc_html__( 'HOVER', 'fielder-elementor' )]
        );

        if ( $style_opts['include_color'] ) {
            $this->add_control(
                $section_id . '_hover_color',
                [
                    'label' => esc_html__($style_opts['color_prefix'].'Color', 'fielder-elementor'),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        "{{WRAPPER}} .".$style_opts['color_hover_class'] => 'color: {{VALUE}} !important;',
                    ],
                ]
            );
        }

        if ( $style_opts['additional_color'] ) {
            $this->add_control(
                $section_id . '_' . $style_opts['additional_color_name'] . '_hover_text_color',
                [
                    'label' => esc_html__( $style_opts['additional_color_name'], 'fielder-elementor'),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                           $style_opts['additional_color_hover_class'] => 'color: {{VALUE}}; fill: {{VALUE}};'
                    ],
                ]
            );
        }

        if ( $style_opts['include_bg'] ) {
            $this->add_group_control(
                Group_Control_Background::get_type(),
                [
                    'name' => $section_id . '_background_hover',
                    'label' => esc_html__('Background type', 'fielder-elementor'),
                    'types' => ['classic', 'gradient', 'video'],
                    'selector' => "{{WRAPPER}} .".$style_opts['html_class'].":hover",
                ]
            );
        }

        if ( $style_opts['include_transition'] ) {
            $this->add_control(
                $section_id.'_hover_transition',
                [
                    'label' => esc_html__( 'Hover transition duration', 'fielder-elementor' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 's' ],
                    'range' => [
                        's' => [
                            'min' => 0.1,
                            'max' => 5,
                            'step' => 0.1,
                        ],
                    ],
                    'default' => [
                        'unit' => 's',
                        'size' => 0,
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .'.$style_opts['html_class'] => 'transition: color {{SIZE}}{{UNIT}}, background {{SIZE}}{{UNIT}}, box-shadow {{SIZE}}{{UNIT}}, border-radius {{SIZE}}{{UNIT}}, border {{SIZE}}{{UNIT}}, filter {{SIZE}}{{UNIT}}, stroke {{SIZE}}{{UNIT}};',
                        $style_opts['additional_transition_selector'] => 'transition: color {{SIZE}}{{UNIT}}, background {{SIZE}}{{UNIT}}, box-shadow {{SIZE}}{{UNIT}}, border-radius {{SIZE}}{{UNIT}}, border {{SIZE}}{{UNIT}}, filter {{SIZE}}{{UNIT}}, stroke {{SIZE}}{{UNIT}};;'
                    ],
                ]
            );
        }

        $this->add_control(
            $section_id.'_separate_hover',
            [
                'type' => Controls_Manager::DIVIDER,
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => $section_id.'_border_hover',
                'label' => esc_html__( 'Border Type', 'fielder-elementor' ),
                'selector' => "{{WRAPPER}} .".$style_opts['html_class'].":hover",
            ]
        );

        $this->add_responsive_control(
            $section_id.'_border_radius_hover',
            [
                'label' => esc_html__( 'Border radius', 'fielder-elementor' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    "{{WRAPPER}} .".$style_opts['html_class'].":hover" => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => $section_id.'_box_shadow_hover',
                'label' => esc_html__( 'Box Shadow', 'fielder-elementor' ),
                'selector' => "{{WRAPPER}} .".$style_opts['html_class'].":hover",
            ]
        );

        $this->end_controls_tab();

        if ( $style_opts['include_active_tab'] ) {

            $this->start_controls_tab(
                $section_id . '_focus_style_tab',
                ['label' => esc_html__( $style_opts['active_tab_name'], 'fielder-elementor' )]
            );

            if ( $style_opts['include_color'] ) {
                $this->add_control(
                    $section_id . '_active_color',
                    [
                        'label' => esc_html__( $style_opts['color_prefix'] . 'Color', 'fielder-elementor '),
                        'type' => Controls_Manager::COLOR,
                        'scheme' => [
                            'type' => Color::get_type(),
                            'value' => $style_opts['color_scheme_default'],
                        ],
                        'selectors' => [
                            "{{WRAPPER}} ." . $style_opts['color_active_class'] => 'color: {{VALUE}} !important;',
                        ],
                    ]
                );
            }

            if ( $style_opts['additional_color'] ) {
                $this->add_control(
                    $section_id . '_' . $style_opts['additional_color_name'] . '_active_text_color',
                    [
                        'label' => esc_html__( $style_opts['additional_color_name'], 'fielder-elementor' ),
                        'type' => Controls_Manager::COLOR,
                        'scheme' => [
                            'type' => Color::get_type(),
                            'value' => $style_opts['additional_color_scheme_default'],
                        ],
                        'selectors' => [
                            "{{WRAPPER}} ." . $style_opts['additional_color_active_class'] => 'color: {{VALUE}} !important; fill: {{VALUE}};',
                        ],
                    ]
                );
            }

            if ( $style_opts['include_bg'] ) {
                $this->add_group_control(
                    Group_Control_Background::get_type(),
                    [
                        'name' => $section_id . '_background_active',
                        'label' => esc_html__( 'Background type', 'fielder-elementor' ),
                        'types' => ['classic', 'gradient', 'video'],
                        'selector' => "{{WRAPPER}} ." . $style_opts['active_class'],
                    ]
                );
            }

            $this->add_control(
                $section_id . '_separate_active',
                [
                    'type' => Controls_Manager::DIVIDER,
                ]
            );

            $this->add_group_control(
                Group_Control_Border::get_type(),
                [
                    'name' => $section_id . '_border_active',
                    'label' => esc_html__( 'Border Type', 'fielder-elementor' ),
                    'selector' => "{{WRAPPER}} ." . $style_opts['active_class'],
                ]
            );

            $this->add_responsive_control(
                $section_id . '_border_radius_active',
                [
                    'label' => esc_html__( 'Border radius', 'fielder-elementor' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => ['px', '%', 'em'],
                    'selectors' => [
                        "{{WRAPPER}} ." . $style_opts['active_class'] => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Box_Shadow::get_type(),
                [
                    'name' => $section_id . '_box_shadow_active',
                    'label' => esc_html__( 'Box Shadow', 'fielder-elementor' ),
                    'selector' => "{{WRAPPER}} ." . $style_opts['active_class'],
                ]
            );

            $this->end_controls_tab();

        }


        $this->end_controls_tabs();
    }

    /**
     * Add widget controls: Style -> Section Style Fields.
     *
     * @since 1.0.0
     * @access private
     *
     * @return void
     **/
    private function section_style_fields() {

        $this->start_controls_section( 'section_style_fields', [
            'label' => esc_html__( 'Field', 'fielder-elementor' ),
            'tab'   => Controls_Manager::TAB_STYLE
        ] );

        $this->generate_margin_padding_controls(
            'section_style_fields',
            'mdp-fielder-elementor-custom-field'
        );

        $this->add_control(
            'separate_margin_padding_field',
            [
                'type' => Controls_Manager::DIVIDER,
            ]
        );

        $this->add_responsive_control(
            'icon_size',
            [
                'label' => esc_html__( 'Icon size', 'fielder-elementor' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 20,
                ],
                'selectors' => [
                    '{{WRAPPER}} .mdp-fielder-elementor-icon' => 'font-size: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .mdp-fielder-elementor-icon svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'after'
            ]
        );


        $this->generate_typography_tabs_controls( 'section_style_fields', [
            'html_class' => 'mdp-fielder-elementor-custom-field',
            'color_class' => 'mdp-fielder-elementor-custom-field',
            'color_hover_class' => 'mdp-fielder-elementor-custom-field:hover',
            'typography_class' => 'mdp-fielder-elementor-custom-field',
            'additional_color_class' => 'mdp-fielder-elementor-icon',
            'additional_color_hover_class' => '{{WRAPPER}} .mdp-fielder-elementor-custom-field-text-wrapper:hover .mdp-fielder-elementor-icon i',
            'additional_color' => true,
            'additional_transition_selector' => '{{WRAPPER}} .mdp-fielder-elementor-icon i',
            'additional_color_name' => 'Icon color'
        ] );

        $this->end_controls_section();

    }

    /**
     * Add widget controls: Style -> Section Style Prefix.
     *
     * @since 1.0.0
     * @access private
     *
     * @return void
     **/
    private function section_style_prefix() {

        $this->start_controls_section( 'section_style_prefix', [
            'label' => esc_html__( 'Prefix', 'fielder-elementor' ),
            'tab'   => Controls_Manager::TAB_STYLE
        ] );

        $this->generate_margin_padding_controls(
            'section_style_prefix',
            'mdp-fielder-elementor-prefix'
        );

        $this->generate_typography_tabs_controls('section_style_prefix', [
            'html_class' => 'mdp-fielder-elementor-prefix',
            'color_class' => 'mdp-fielder-elementor-prefix',
            'typography_class' => 'mdp-fielder-elementor-prefix',
            'color_hover_class' => 'mdp-fielder-elementor-prefix:hover'
        ] );

        $this->end_controls_section();

    }

    /**
     * Add widget controls: Style -> Section Style Suffix.
     *
     * @since 1.0.0
     * @access private
     *
     * @return void
     **/
    private function section_style_suffix() {

        $this->start_controls_section( 'section_style_suffix', [
            'label' => esc_html__( 'Suffix', 'fielder-elementor' ),
            'tab'   => Controls_Manager::TAB_STYLE
        ] );

        $this->generate_margin_padding_controls(
            'section_style_suffix',
            'mdp-fielder-elementor-suffix'
        );

        $this->generate_typography_tabs_controls('section_style_suffix', [
            'html_class' => 'mdp-fielder-elementor-suffix',
            'color_class' => 'mdp-fielder-elementor-suffix',
            'typography_class' => 'mdp-fielder-elementor-suffix',
            'color_hover_class' => 'mdp-fielder-elementor-suffix:hover'
        ] );

        $this->end_controls_section();

    }


    /**
     * Find value in array by key.
     *
     * @param $input_array
     * @param $find_key
     * @return false
     * @since 1.0.0
     * @access private
     *
     */
    private function find_value_in_array( $input_array, $find_key ) {
        foreach ( $input_array as $key => $value ) {
            if ( $find_key == $key ) {
                return $value;
            } elseif ( is_array( $value ) ) {
                $tmp = $this->find_value_in_array( $value, $find_key );
                if ( $tmp !== false ) {
                    return $tmp;
                }
            }
        }
        return false;
    }

    /**
     * Method for generating icon.
     *
     * @param $item
     * @return string
     * @since 1.0.0
     * @access private
     */
    private function generate_icon( $item ) {

        $icon = $item['field_icon']['library'] === 'svg' ?
            Icons_Manager::render_uploaded_svg_icon( $item['field_icon']['value'] ) :
            '<i class="'.esc_attr( $item['field_icon']['value'] ).'"></i>';

        return sprintf(
            '<div class="mdp-fielder-elementor-icon">%s</div>',
                   $icon
        );
    }

    /**
     * Method for generating suffix.
     *
     * @param $item
     * @return string
     * @since 1.0.0
     * @access private
     */
    private function create_suffix( $item ) {

        $suffix = esc_html( $item['field_suffix'] );

        return sprintf( '<div class="mdp-fielder-elementor-suffix">%s</div>', $suffix );
    }

    /**
     * Method for generating prefix.
     *
     * @param $item
     * @return string
     * @since 1.0.0
     * @access private
     */
    private function create_prefix( $item ) {

        $prefix = esc_html( $item['field_prefix'] );

        return sprintf( '<div class="mdp-fielder-elementor-prefix">%s</div>', $prefix );
    }


    /**
     * Method for generating field text wrapper.
     *
     * @param $custom_field
     * @param $output_content
     * @param $suffix
     * @param $prefix
     * @return string
     * @since 1.0.0
     * @access private
     */
    private function generate_custom_field_text_wrapper( $custom_field, $output_content, $suffix, $prefix ) {

        $wrapper = '';

        $field_icon = $custom_field['show_icon'] === 'yes' ? $this->generate_icon( $custom_field ) : '';
        $field_icon_position = 'mdp-fielder-elementor-icon-position-' . esc_attr( $custom_field['icon_position'] );

        $link_type = $custom_field['field_as_slug_link'] === 'yes' ?
            'slug_link' :
            ( ( $custom_field['custom_link'] ) ?
                'custom_link' : 'none'
            );

        switch ( $link_type ) {
            case 'none':
                $wrapper = sprintf(
                '<div class="mdp-fielder-elementor-custom-field-text-wrapper %s">
                            %s
                            <div class="mdp-fielder-elementor-custom-field">%s %s %s</div>  
                       </div>',
                    $field_icon_position,
                    $field_icon,
                    $prefix,
                    wp_kses_post( $output_content ),
                    $suffix
                );
            break;
            case 'custom_link':
                $this->add_link_attributes( 'custom_link', $custom_field['custom_link_url'] );
                $wrapper = sprintf(
                '<a %s class="mdp-fielder-elementor-custom-field-text-wrapper %s">
                            %s
                            <div class="mdp-fielder-elementor-custom-field">%s %s %s</div>  
                        </a>',
                    $this->get_render_attribute_string( 'custom_link' ),
                    $field_icon_position,
                    $field_icon,
                    $prefix,
                    wp_kses_post( $output_content ),
                    $suffix
                );
                break;
            case 'slug_link':
                $post_by_slug = get_page_by_path( $custom_field['custom_field'], OBJECT, ['post', 'page'] );
                $link = get_permalink( $post_by_slug );
                $wrapper = sprintf(
                '<a href="%s" class="mdp-fielder-elementor-custom-field-text-wrapper %s">
                            %s
                            <div class="mdp-fielder-elementor-custom-field">%s %s %s</div>  
                        </a>',
                    esc_url( $link ),
                    $field_icon_position,
                    $field_icon,
                    $prefix,
                    wp_kses_post( $output_content ),
                    $suffix
                );
                break;
        }

        return $wrapper;
    }

    /**
     * Method for generating custom field.
     *
     * @param $custom_field
     * @param $output_content
     * @return string
     * @since 1.0.0
     * @access private
     */
    private function generate_custom_field( $custom_field, $output_content ) {

        $suffix = $custom_field['field_suffix'] !== '' ? $this->create_suffix( $custom_field ) : '';
        $prefix = $custom_field['field_prefix'] !== '' ? $this->create_prefix( $custom_field ) : '';

        return sprintf(
     '<div class="mdp-fielder-elementor-custom-field-wrapper mdp-fielder-elementor-text-align-%s 
                elementor-repeater-item-%s">%s</div>',
            esc_attr( $custom_field['custom_field_text_align'] ),
            esc_attr( $custom_field['_id'] ),
            $this->generate_custom_field_text_wrapper(
                $custom_field,
                $output_content,
                $suffix,
                $prefix
            )
        );
    }

    /**
     * Method for generating custom fields.
     *
     * @param $settings
     * @return string
     * @since 1.0.0
     * @access private
     *
     */
    private function generate_custom_fields( $settings ) {

        $fields = [];

        foreach ( $settings['custom_fields'] as $custom_field ) {

            $custom_field_content = class_exists( 'ACF' ) ?
                                    get_field( $custom_field['custom_field'] ) :
                                    get_post_meta( get_the_ID(), $custom_field['custom_field'] );

            if ( empty( $custom_field_content ) ) { continue; }

            if ( $custom_field['custom_field_type'] === 'array' ) {
                $error_message = is_admin() ?
                    esc_html__( 'Custom field is not an array!', 'fielder-elementor' ) :
                    false;
                $result = is_array( $custom_field_content ) ?
                          $this->find_value_in_array( $custom_field_content, $custom_field['array_key'] ) :
                          $error_message;
                $object_sub_field_message = is_admin() ? 'object' : '';
                $array_sub_field_message = is_admin() ? 'array' : '';
                $output_content =  is_array( $result ) ?
                                  $array_sub_field_message :
                                  ( ( is_object( $result ) ) ?
                                  $object_sub_field_message :
                                  $result );
                $fields[] = $output_content !== false ?
                    $this->generate_custom_field( $custom_field, $output_content ) :
                    '';
            } elseif ( $custom_field['custom_field_type'] === 'text' ) {
                $error_message = is_admin() ?
                            esc_html__( 'Custom field is not a text!', 'fielder-elementor' ) :
                            false;
                if ( class_exists( 'ACF' ) ) {
                    $output_content = is_string( $custom_field_content ) ?
                        $custom_field_content :
                        $error_message;
                } else {
                    $output_content = $custom_field_content[0];
                }
                $fields[] = $output_content !== false ?
                    $this->generate_custom_field( $custom_field, $output_content ) :
                    '';
            } elseif ( $custom_field['custom_field_type'] === 'object' ) {
                $object_key = $custom_field['object_key'];
                $error_message = is_admin() ?
                    esc_html__( 'Custom field is not an object!', 'fielder-elementor' ) :
                    false;
                $output_content = is_object( $custom_field_content ) ?
                                  $custom_field_content->$object_key :
                                  $error_message;
                $object_sub_field_message = is_admin() ? 'object' : '';
                $array_sub_field_message = is_admin() ? 'array' : '';
                $result = is_array( $output_content ) ?
                          $array_sub_field_message :
                          ( ( is_object( $output_content ) ) ?
                          $object_sub_field_message :
                          $output_content );
                $fields[] = $result !== false ?
                    $this->generate_custom_field( $custom_field, $result ) :
                    '';
            }

        }

        return implode( '', $fields );
    }

    /**
     * Render Frontend Output. Generate the final HTML on the frontend.
     *
     * @access protected
     *
     * @return void
     **/
    protected function render() {
        $settings = $this->get_settings_for_display();

        echo sprintf(
                '<!-- Start Fielder for Elementor WordPress Plugin -->
                        <div class="mdp-fielder-elementor-box">%s</div>
                        <!-- End Fielder for Elementor WordPress Plugin -->',
                        $this->generate_custom_fields( $settings )
        );

    }

    /**
     * Return link for documentation
     * Used to add stuff after widget
     *
     * @access public
     *
     * @return string
     **/
    public function get_custom_help_url() {

        return 'https://docs.merkulov.design/tag/fielder';

    }

}
