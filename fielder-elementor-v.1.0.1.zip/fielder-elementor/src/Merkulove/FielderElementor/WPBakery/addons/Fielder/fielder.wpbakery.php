<?php
/**
 * Fielder for Elementor
 * Customizable custom fields for Elementor editor
 * Exclusively on https://1.envato.market/fielder-elementor
 *
 * @encoding        UTF-8
 * @version         1.0.1
 * @copyright       (C) 2018 - 2022 Merkulove ( https://merkulov.design/ ). All rights reserved.
 * @license         Envato License https://1.envato.market/KYbje
 * @contributors    Nemirovskiy Vitaliy (nemirovskiyvitaliy@gmail.com), Dmitry Merkulov (dmitry@merkulov.design), Cherviakov Vlad (vladchervjakov@gmail.com)
 * @support         help@merkulov.design
 **/

namespace Merkulove\FielderElementor;

/** Exit if accessed directly. */
if ( ! defined( 'ABSPATH' ) ) {
    header( 'Status: 403 Forbidden' );
    header( 'HTTP/1.1 403 Forbidden' );
    exit;
}

use Exception;
use Merkulove\FielderElementor\Unity\Plugin as UnityPlugin;

class wpbFielder {

	/**
	 * Get things started.
	 *
	 * @throws Exception
	 * @since  1.0.0
	 * @access public
	 **/
	public function __construct() {

		/** Fielder addon map. */
        $this->params_map();

		/** Shortcode for Fielder addon. */
		add_shortcode( 'mdp_wpb_fielder', [ $this, 'render' ] );

		/** Register CSS and JS */
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue' ] );

	}

	/**
	 *
	 */
	public function enqueue() {

        /** Front-End Styles */
//		wp_register_style( 'mdp-fielder-wpbakery', UnityPlugin::get_url() . 'css/fielder-wpbakery' . UnityPlugin::get_suffix() . '.css', [], UnityPlugin::get_version() );
//		wp_enqueue_style( 'mdp-fielder-wpbakery' );

        /** Front-End Scripts */
//		wp_enqueue_script( 'mdp-fielder-wpbakery', UnityPlugin::get_url() . 'js/fielder-wpbakery' . UnityPlugin::get_suffix() . '.js', [ 'jquery' ], UnityPlugin::get_version(), true);

	}

    /**
     * Shortcode [mdp_wpb_fielder] output.
     *
     * @param $atts array - Shortcode parameters.
     *
     * @return false|string
     * @since 1.0.0
     * @access public
     **/
    public function render( $atts ) {

        ob_start();

        return ob_get_clean();

    }

    /**
     * Fielder addon map.
     *
     * @throws Exception
     **/
    public function params_map() {

        /** Check, just in case. */
        if ( ! function_exists( 'vc_map' ) ) { return; }

        /** Control params. */
        $params = [];

        /** Add [mdp_wpb_fielder] shortcode to the WPBakery Page Builder */
        vc_map( [
            'name'                    => esc_html__( 'Fielder', 'fielder-elementor' ),
            'description'             => '',
            'base'                    => 'mdp_wpb_fielder',
            'icon'                    => 'icon-mdp-fielder-wpbakery',
            'category'                => esc_html__( 'Content', 'fielder-elementor' ),
            'show_settings_on_create' => true,
            'params'                  => $params,
        ] );

    } // END Class wpbFielder.

}
/** Run Fielder addon. */
new wpbFielder();